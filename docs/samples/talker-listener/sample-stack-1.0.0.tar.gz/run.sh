#!/usr/bin/env bash
set -e
echo "demo running"
sleep 300
